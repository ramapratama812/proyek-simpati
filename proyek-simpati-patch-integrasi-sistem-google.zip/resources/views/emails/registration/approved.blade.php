<p>Halo {{ $user->name }},</p>

<p>Selamat, akun SIMPATI kamu telah terdaftar dan sudah aktif.</p>

<p>
    Kamu bisa masuk ke sistem melalui tombol berikut:<br>
    <a href="{{ url('/login') }}"
       style="display:inline-block;padding:10px 16px;background:#2563eb;color:#fff;text-decoration:none;border-radius:4px;">
        Masuk ke SIMPATI
    </a>
</p>

<p>
    Untuk pengguna dengan email Politala, kamu bisa login menggunakan tombol
    "Login dengan Google" di halaman login.
</p>

<p>Salam,<br>
Tim SIMPATI</p>
